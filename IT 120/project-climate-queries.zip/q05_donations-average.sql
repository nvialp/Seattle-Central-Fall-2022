-- Compute the average value of a donation (AVG)

SELECT AVG(Amount) FROM Donation;
