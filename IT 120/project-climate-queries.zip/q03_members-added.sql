-- List all the members who were added in 2020 (Use the EXTRACT
-- function to get the year). Show newest members first.
-- Show their name and date they became a member.
--
-- 11 points
--

SELECT FIXME
;
