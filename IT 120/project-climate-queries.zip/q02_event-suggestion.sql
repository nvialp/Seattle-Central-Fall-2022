-- INSERT a member event suggestion. The event should show it has not
-- been approved by the staff.
--
-- 5 points
--

INSERT FIXME
;
