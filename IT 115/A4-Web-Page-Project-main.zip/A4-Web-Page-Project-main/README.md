### A4-Web-Page-Project
Group 2 Assignment 4

This web page shares reviews of some new restaraunts that have recently opened. Everything from food quality to staff friendliness will be discussed.
We hope you enjoy reading our detailed reviews. 

Bon Appetit!

![image](https://user-images.githubusercontent.com/93103705/197274054-ef0b9a9f-4329-4a73-be4d-7ba98aa47e87.png)

Recipes for Healthy Living, Taste of Home Cooking, Entertaining Friends!  Smell the aroma, create taste to your liking, devour meals you love and enjoy! List of Ingredients and Instructions to create delicious meals all at your finger tips. Take a peek and put a touch or pinch of whatever to make it your very own :)

![image](https://user-images.githubusercontent.com/94158648/197680255-82cbe7f0-6d04-455a-8991-2891a7f3dd63.png)

# Delicious Recipes to your delight
Bon Appétit! Recipes for Healthy Living, Taste of Home Cooking, Entertaining Friends! Smell the aroma, create taste to your liking, devour meals you love and enjoy! 

![image](https://user-images.githubusercontent.com/94158648/197680406-9e23fc99-22cd-49f1-b85d-5ea882dcdfc4.png)

![wide-middle-eastern-food](https://user-images.githubusercontent.com/94158648/141925708-5e0eeef7-bc15-4913-aa6a-c52c8e9572d1.jpg)

List of Ingredients and Instructions to create delicious meals all at your finger tips. Take a peek and put a touch or pinch of whatever to make it your very own :)

![Ashenda Tigray](https://user-images.githubusercontent.com/94158648/142278055-6b75684a-9ebe-4e90-8e20-d4fc7d16d7e4.jpg)

# Recipes by GENET's TIGRAY RESTAURANT: 
![Tihilo](https://user-images.githubusercontent.com/94158648/142278022-d6ae65f6-3c4d-4879-9161-55d9c3003ac6.jpg)
Genet's Favorite Traditional Dishes from her hometown of Adigrat, Tigray: Tihilo

'Tihlo (Tigrinya: ቲህሎ) is a dish from the historical Agame province in Northern most parts of Ethiopia that consists of barley dough balls covered with meat and berbere (berbere is made of chili after is is dried and powdered) based sauce often served as a snack. Tihlo is commonly consumed as a side dish or snack, especially in Ethiopia's northern communities, specifically the Tigray people. The barley grain is completely dehulled and milled. Tihlo is made using moistened roasted barley flour that is kneaded to a uniform consistency. The dough is then broken into small balls and laid out around a bowl of spicy meat stew. A two-pronged wooden fork is used to spear the ball and dip it into the stew. Tihlo is commonly served on cultural holidays.'

# Potato and Cabbage Dish

![image](https://user-images.githubusercontent.com/94158648/197901818-1e680f7a-be01-4f89-815c-0f432a47f94e.png)

Inexpensive ingredients, but healthy, rich in flavor, texture and Tumeric aroma - A soup and A stew!
Served Vegan or add a bit of meat for meat lovers - Perfect combination.

Other Healthy Meals to Fuel Your Day:
![brussels sprouts with pp](https://user-images.githubusercontent.com/94158648/141927117-5187f130-6cd6-439f-a767-6dcc4755f4fb.jpg)
'Skillet-Roasted Brussels Sprouts with Pomagranate and Pistachios'

[Brussel Sprouts With Pistachios Recipe](https://github.com/Tigray11/IT100-Recipe-/blob/main/Skillet-Roasted%20Brussels%20Sprouts%20With%20Pomegranate%20and%20Pistachios)

![Pesto pasta](https://user-images.githubusercontent.com/94158648/141927156-0e839623-7509-4407-a353-7012a594c34f.jpg)
'Broccoli-Walnut Pesto Pasta'

[Pesto Pasta Recipe](https://github.com/Tigray11/IT100-Recipe-/blob/main/Nuts%20for%20Broccoli-Walnut%20Pesto%20Pasta)

![Almond Tea Bread Recipe](https://user-images.githubusercontent.com/94158648/141927166-0fe25bc4-1eb0-4b0c-a972-03957c85cd4d.jpeg)
'Almond Tea Bread'

[Delicious Almond Tea Bread Recipe to your liking - Follow these easy steps and add your favorite flavors](https://github.com/Tigray11/IT100-Final-Project---Recipes---Genet-Marissa-Renee/blob/main/Almond%20Tea%20Bread%202)

![chili](https://user-images.githubusercontent.com/94158648/141927358-62eb81cf-83b5-4d66-a92c-8c1a51212ca9.png)
'Chili'

[Chili Recipe](https://github.com/Tigray11/IT100-Recipe-/blob/main/Making%20Delicious%20Chili)
 
![Salmon](https://user-images.githubusercontent.com/94158648/141931713-fb02fab3-b75c-4929-9614-481a02e08b9f.jpg)
'Fresh Salmon'

[Salmon Recipe](https://github.com/Tigray11/IT100-Final-Project---Recipes---Genet-Marissa-Renee/blob/main/Fresh%20Salmon)

# Additional Recipes for you to Enjoy with your Family and Friends!
![Long table dinner](https://user-images.githubusercontent.com/94158648/142280899-670f7bda-0b62-4bb4-8fa4-c9520bb0c6ae.jpg)

# FINE DINING CHEF MARISSA:

![MarissaChefOutfit](https://user-images.githubusercontent.com/93103705/144161901-c32657a9-3b1f-4560-903c-017356fac8cd.jpg)

![hasenpfeffer stew](https://user-images.githubusercontent.com/93103705/144162388-3c368475-8c56-4bb8-89e9-8ff413831d08.jpg)


[Rabbit Stew Recipe](https://github.com/marissadashen/Hasenpfeffer-Rabbit-Stew.git)

![yakh-dar-behesht Rosewater Custard](https://user-images.githubusercontent.com/93103705/144162439-5c312455-31fc-4f28-938d-9eb412707041.jpg)


[Rosewater Custard Recipe](https://github.com/marissadashen/Rosewater-Custard.git)


![Pecan Butter Sauce Fish](https://user-images.githubusercontent.com/93103705/144162477-b2e8eb04-b6f6-4f9e-bc62-e0001c22c516.jpg)

[Pecan Butter Sauce Recipe](https://github.com/marissadashen/Pecan-Butter-Sauce.git)

![Cottage Cheese Dumplings](https://user-images.githubusercontent.com/93103705/144162512-4ea4ab80-a699-4ad6-9256-808c9d21558f.jpg)


[Cottage Cheese Dumplings Recipe](https://github.com/marissadashen/Cottage-Cheese-Dumplings.git)

![Callaloo](https://user-images.githubusercontent.com/93103705/144162540-0719678f-c69c-451e-b8e5-55d62d7a7248.jpg)

[Callaloo Recipe](https://github.com/marissadashen/Callaloo.git)

![cooking-for-beginners-cooking-techniques-and-tips](https://user-images.githubusercontent.com/94158648/142270571-6e8b12ff-20f5-4ff2-a44f-1eec19cfe49f.jpg)

![Dinnerparty](https://user-images.githubusercontent.com/94158648/142280928-9fed48dd-987e-4968-b03c-f97834fe93d1.jpg)

![Dessert_Recipe_Custard_Jelly_Biscuit_Pudding-2](https://user-images.githubusercontent.com/94158648/142275350-8da0817e-2626-4050-86f7-135c49217a76.jpg)


![desserts](https://user-images.githubusercontent.com/94158648/142275404-23fcfadc-feb8-4130-99e6-c6096daedace.jpg)


# Mexican + Samoa Remix Delight by Nicholas:
![Samoan-People-and-Their-Culture-1](https://user-images.githubusercontent.com/94158648/142278208-243bb295-1f4f-4593-b08d-7ec1adf4a0bf.jpg)

![Samoan Culture 2](https://user-images.githubusercontent.com/94158648/146057157-f25487b0-cb2e-43ab-a751-465d2267159c.jpg)

![Culture last](https://user-images.githubusercontent.com/94158648/146056976-1fc3eac1-3b4c-413a-9328-c7d8be859c50.jpg)

Young taro leaves (make sure that the stem is still green, if it’s red, do not use it) You will need 4 – 6 leaves for each serving, depending on size. So, if you are making 8 servings, you will need 32 – 48 leaves.
2 cans of creamy style coconut milk (if you cannot find ‘creamy’ you can use standard coconut milk)
One medium to large onion, chopped
Salt, to taste (as you can see, I used a wonderful Hawaiian salt)
Pepper (optional)
2 cups water
In a bowl, mix together the coconut milk, onions, salt and pepper
Take the washed and dried taro leaves and begin building a bowl on the palm of your hand. Notice how fresh these young leaves, straight off the plant, are. Leaves from the store tend to be a bit more ragged, but they still work.
Using the largest leaf on the bottom, begin stacking leaves on top, each smaller than the other. You will want to use 4 – 6 leaves each serving.
Now, spoon the coconut milk mixture into the bowl of the taro leaves. Fill it up about half way, maybe a cup or so, but not so much that it overflows when you wrap it.
For true island flavor, Samoan palusami is cooked in an umu, but most cooks do not have a pit oven available. Not to worry! An electric steamer is the most common method for many Polynesian families, and it makes the dish guaranteed tender! Simply place prepared palusamis in the steamer with the required amount of water and cook for at least 4 hours or more. 

![Renee's Culture 1](https://user-images.githubusercontent.com/94158648/146057278-83e111b5-771e-4e80-8559-21fdf177d26b.jpg)

# Recipe to Enjoy!

![mexican 2](https://user-images.githubusercontent.com/94158648/142275581-76d0670f-a585-4341-9ef6-2d109121c9f4.jpg)

![Chicken Tinga](https://user-images.githubusercontent.com/94158648/146058437-7ab8b5f5-ad4f-4456-8789-0ca730e40deb.jpg)

[Chicken Tinga Recipe](https://github.com/rtautua1827/Chicken-Tinga-Recipe.git)

![Renee's Rice](https://user-images.githubusercontent.com/94158648/146058054-f9249de9-7cb1-46ea-9eb2-796d662c26d8.jpg)

[Authentic Mexican Rice Recipe](https://github.com/rtautua1827/Authentic-Mexican-Rice-Recipe.git)

![Renee's Flan](https://user-images.githubusercontent.com/94158648/146057698-a7271086-2e18-42c5-aae5-b65630c1df5c.jpg)

[Mexican Flan](https://github.com/rtautua1827/Mexican-Flan.git)

![Renee's Beans](https://user-images.githubusercontent.com/94158648/146057873-621772a8-63e3-40a1-ad6e-4348015caa29.jpg)

[Mexican Beans](https://github.com/rtautua1827/Mexican-Beans.git)

![Renee's Arroz Con Leche](https://user-images.githubusercontent.com/94158648/146058288-7c025a62-8f44-4a91-98cc-f5e823dc470f.jpg)

[Arroz Con Leche](https://github.com/rtautua1827/Arroz-con-leche.git)

![samoa food](https://user-images.githubusercontent.com/94158648/142275455-ca04e30a-ba44-4cf7-b20f-ded9cf2b5a85.JPG)

![mexican](https://user-images.githubusercontent.com/94158648/142275509-898f3b1a-a51f-4577-ba07-d914a4148062.jpg)

![Mango-Cream-Tart_EXPS_JMZ18_224490_D03_08__5b](https://user-images.githubusercontent.com/94158648/142275633-1d09d581-9ab2-44af-9aaf-3d255dc09052.jpg)

![Samoan](https://user-images.githubusercontent.com/94158648/142279443-5da67092-563b-45be-be3a-28aec3c72776.jpg)

# Wok-It-Out with Jomar

# DIG IN!

![Serving Dinner](https://user-images.githubusercontent.com/94158648/142281012-6a7e78c4-4672-4d61-af94-5f5c64e7a37d.jpg)

![Family_eating_meal_together_skynesher_Getty_Images](https://user-images.githubusercontent.com/94158648/142270434-ca902e90-de84-4323-8fba-d097cc52606f.jpg)

![christmas dinner](https://user-images.githubusercontent.com/94158648/142270474-2eee4c35-ccae-41b0-bf59-a2fd994e7501.jpg)

![family and friends dinner](https://user-images.githubusercontent.com/94158648/142281135-f7db40a4-4afa-4d03-840c-aea80f0697da.jpg)


![TRUTHTV-family-with-kids-1024x576](https://user-images.githubusercontent.com/94158648/142270622-5e038caa-10f3-4cf9-80b0-0aaeee4fe47c.jpg)


