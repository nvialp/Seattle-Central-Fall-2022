-- Compute the total value of the donations listed (SUM)
--
-- 5 points
--

SELECT FIXME
;
